STITCH — IIT ROORKEE PRESENTATION: EDITABLE LATEX PROJECT

Author: PRONOB BHATTACHARJEE, enrollment 25565017.
Supervisor: Dr. R. Balasubramanian.

OVERLEAF: Upload this ZIP; select Stitch_IITR_Presentation.tex and pdfLaTeX.
LOCAL: latexmk -pdf -outdir=build Stitch_IITR_Presentation.tex, or make.

The original beamerthemeIITR.sty, institutional crests, slide_bg.png,
titleslide_bg.png campus photograph and white_bg.png are bundled.
Results are the actual retained Stitch measurements; no experiments are rerun
for this presentation. It uses the original 4:3 IITR theme.

POWERPOINT: The companion PPTX is a faithful full-slide-image export of this
LaTeX PDF at 1920px width, with extracted text in speaker notes. Edit the TeX
master to change slide text, then recompile/export; PPTX text boxes are not
separately editable. This preserves the exact math, fonts and artwork.
