STITCH — IIT ROORKEE REPORT: EDITABLE LATEX PROJECT

Author: PRONOB BHATTACHARJEE, enrollment 25565017.
Supervisor: Dr. R. Balasubramanian (confirmed by the author).

OVERLEAF: Upload this ZIP as a project; select main.tex and pdfLaTeX.
LOCAL: run latexmk -pdf -outdir=build main.tex, or make.
The .latexmkrc also generates the nomenclature through MakeIndex.

All crests, figures, tables and code listings are bundled. No parent folder,
external image path, Python environment, dataset or model download is required
to compile this fixed report snapshot. Numeric tables are generated from the
retained Stitch measurements; the full research project supplies regeneration.

The original reference report was not overwritten. The cover layout, margins,
Latin Modern typography, institutional wording and embedded crest follow the
supplied PRONOB BHATTACHARJEE thesis. The project title/content are Stitch.
Certification remains unsigned for supervisor/institutional review.
